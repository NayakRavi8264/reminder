<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use \Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class CreditPayment extends Model
{
    use HasFactory, UserActionsBy;
    
    public $table = 'credit_payments';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'id',
        'payment_type', 
        'date', 
        'net_bill_amount', 
        'gst_slab',
        'gst_amount',
        'bill_amount', 
        'income_tax',
        'lcess', 
        'cgst_tds',
        'sgst_tds', 
        'security_deposit',
        'royality',
        'time_lime', 
        'other_deposit', 
        'total_deduction', 
        'cheq_amount', 
        'client_id',
        'user_id', 
        'project_id',
        'remark',
        'created_at', 
        'updated_at', 
        'deleted_at', 
        'created_by',
        'updated_by',
        'deleted_by'
    ];

    public function user(){
        return $this->hasOne(User::class, 'id', 'created_by');
    }

    public function party(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function payment(){
        return $this->hasOne(Bank::class, 'id', 'payment_type');
    }

    public function project(){
        return $this->hasOne(Project::class, 'id', 'project_id');
    }

    public function client(){
        return $this->hasOne(Client::class, 'id', 'client_id');
    }
}
