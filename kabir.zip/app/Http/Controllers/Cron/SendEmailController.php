<?php

namespace App\Http\Controllers\Cron;

use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\DB;
use App\Appointment;
use Mail;

class SendEmailController extends Controller {

    public function index() {
        die('');
    }

    public function sendEmailsToNurse() {
        $date =
                date('Y-m-d');
        $nurse_data =
                DB::select(
                        "SELECT DISTINCT(user_slots.user_id) AS nurse_id, users.email as email
                        FROM appointments
                        LEFT JOIN user_slots ON user_slots.id = appointments.user_slot_id
                        LEFT JOIN users ON users.id = user_slots.user_id
                        WHERE user_slots.slot_date = '2022-01-03'"
        );
        foreach ($nurse_data as $key => $nurse) {
            $appointments =
                    DB::select(
                            "SELECT 
                user_slots.slot_id,
                CONCAT_WS(' ',nurse.fname,nurse.lname) AS nurse_name,
                CONCAT_WS(' ',users.fname,users.lname) AS user_name ,
                slots.slot_name,
                users.mobile
                FROM `appointments`
                LEFT JOIN user_slots ON user_slots.id = appointments.user_slot_id 
                LEFT JOIN slots ON slots.id = user_slots.slot_id
                LEFT JOIN users ON users.id = appointments.user_id
                LEFT JOIN users as nurse ON nurse.id = user_slots.user_id
                WHERE user_slots.user_id = '{$nurse->nurse_id}' AND user_slots.slot_date = '2022-01-03'
                ORDER BY user_slots.slot_id"
            );
//            echo"<pre>";
//            print_r($nurse_data);
//            die;
//             return view('email_templates.appointment_email_to_nurse_template', compact('appointments'));
            $subject = "Today's Appointments (".date('m-d-Y').")";
            $temp = "emails.appointment_email_to_nurse_template";
            \Mail::to("$nurse->email")->send(new \App\Mail\MyMail($appointments, $subject, $temp));
        }
        dd("Email is Sent.");
    }

    public function sendCancelEmail() {
        $appointments=Appointment::select('id','user_id','user_slot_id','order_id')->with(array('user' => function($query){
                        $query->select('id','email','fname','lname');
                    },'userslot' => function($query){
                        $query->with(array('slot' => function($query1){
                        $query1->select('id','slot_name');
                    }))->select('id','user_id','slot_id','slot_date');
                    }))->where('status',2)->where('send_cancelemail',0)->limit(100)->get();


        foreach ($appointments as $appointment){
            if(Appointment::where('id',$appointment->id)->where('send_cancelemail',0)->exists()){
                $details=$appointment->toArray();
                $details['subject']='Appointment cancellation update for getcovidsafe.com';
                $details['emailtype']='cancel_app_email';
                Appointment::where('id',$appointment->id)->update(['send_cancelemail'=>true]);
                try {
                    Mail::to(trim($appointment->user->email))->send(new \App\Mail\SendEmail($details));
                    
                } catch (Exception $ex) {
                    //return "We've got errors!";
                }
            }
        }
    }
}
