<?php

namespace App\Http\Controllers\Admin;

use App\Task;
use App\Client;
use App\User;
use App\Http\Controllers\Controller;
use DB;

class HomeController extends Controller
{
    public function index()
    {
        $client_count = Client::count();
        $task_count = Task::count();
         $success_task_count = Task::where('status',1)->count();
        $user_count = User::whereHas(
            'roles', function($q){
                $q->where('title','user');
            }
        )->count();
        $count['client_count'] = $client_count;
        $count['task_count'] = $task_count;
        $count['user_count'] = $user_count;
        $count['success_task_count'] = $success_task_count;
        return view('admin.home', compact('count'));
    }
}
