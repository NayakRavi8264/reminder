<?php

namespace App\Http\Controllers\Admin;

use App\DebitPayment;
use App\User;
use App\Project;
use App\Bank;
use App\Http\Requests\StoreDebitPaymentRequest;
use App\Http\Requests\UpdateDebitPaymentRequest;
use App\Http\Requests\MassDestroyDebitPaymentRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;
use Session;

class DebitPaymentController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('debit_payment_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $payments = DebitPayment::select('*');
            // $payments = $payment->get();
            return DataTables::of($payments)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })->addColumn('party', function ($row) {
                    $party = "";
                    if(isset($row->party->fname) && isset($row->party->lname)){
                    return  $party = $row->party->fname .' '.$row->party->lname;
                    }
                })->addColumn('payment', function ($row) {
                    return isset($row->payment->name)?$row->payment->name:"";
                })->addColumn('project', function ($row) {
                    return isset($row->project->name)?$row->project->name:"";
                })->addColumn('action', function($row){
                    $url = url('admin/debit_payments', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('debit_payment_edit')){
       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                if(\Gate::allows('credit_payment_delete2')){
                $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                }
                return $actionBtn;
                })
                ->rawColumns(['action', 'status', 'party','payment','project'])
                ->make(true);
        }
        return view('admin.debit_payments.index');
    }

    public function create() {
        abort_if(Gate::denies('debit_payment_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 3);
            $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $payment_types = Bank::where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        $date = Session::get('date');
        Session::forget('date');
        return view('admin.debit_payments.add_update', compact('users', 'payment_types', 'projects', 'date'));
    }

    public function store(StoreDebitPaymentRequest $request) {
        $data = $request->input();
        $data['created_by'] = auth()->user()->id;
        DebitPayment::create($data);
        Session::put('date', $request->post('date'));
        return redirect()->route('admin.debit_payments.create')->with('message', "Debit Payment added successfully.!");
    }

    public function edit(DebitPayment $debit_payment) {
        abort_if(Gate::denies('debit_payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 3);
            $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $payment_types = Bank::where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        return view('admin.debit_payments.add_update', compact('debit_payment', 'users', 'payment_types', 'projects'));
    }
    public function update(UpdateDebitPaymentRequest $request, DebitPayment $debit_payment) {
        $data = $request->input();
        $data['updated_by'] = auth()->user()->id;
        $debit_payment->update($data);
        return redirect()->route('admin.debit_payments.index')->with('message', "Debit Payment updated successfully.!");
    }


    public function destroy(DebitPayment $debit_payment)
    {
        // abort_if(Gate::denies('credit_payment_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $debit_payment->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyDebitPaymentRequest $request)
    {
        DebitPayment::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
