<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreBankRequest;
use App\Http\Requests\UpdateBankRequest;
use App\Http\Requests\StoreInternalBankRequest;
use App\Http\Requests\MassDestroyBankRequest;
use App\Bank;
use App\DebitPayment;
use App\CreditPayment;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class BankController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('bank_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $banks = \DB::select("SELECT
            banks.*,
            (
            SELECT
              SUM(cheq_amount) AS `cheq_amount`
            FROM
                `credit_payments`
            WHERE
                `credit_payments`.`payment_type` = `banks`.`id` AND `credit_payments`.`deleted_at` IS NULL
        ) as credit_amount,(
            SELECT
                SUM(amount) AS `debit_amt`
            FROM
                `debit_payments`
            WHERE
                `debit_payments`.`payment_type` = `banks`.`id` AND `debit_payments`.`deleted_at` IS NULL
        ) as debit_amount
        FROM
    `banks`");
        return view('admin.banks.index', compact('banks'));
    }

    public function interBankTransfer()
    {
        abort_if(Gate::denies('bank_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $banks = Bank::where('status', 1)->get();
        return view('admin.banks.internal_bank_transfer', compact('banks'));
    }

    public function transferAmount(StoreInternalBankRequest $request)
    {
        abort_if(Gate::denies('bank_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $bank = Bank::where(['status' => 1, 'id' => $request->post('from_bank')])->first();
        $from_bank_total = $bank->credits->sum('cheq_amount') - $bank->debits->sum('amount');
        
        // if($from_bank_total < $request->post('amount')){
        //     return back()->withErrors(['Transfer amount is higher than balance amount of from bank.!']);
        // }
        if($request->post('from_bank') == $request->post('to_bank')){
            return back()->withErrors(['Can\'t transfer in same bank, please choose different.!']);
        }
        
        $credit = [
            'cheq_amount' => $request->post('amount'),
            'payment_type' => $request->post('to_bank'),
            'user_id' => 1000,
            'date' => $request->post('date'),
            'remark' => 'Manual Internal Bank Transfer'
        ];
        $debit = [
            'amount' => $request->post('amount'),
            'payment_type' => $request->post('from_bank'),
            'user_id' => 1000,
            'date' => $request->post('date'),
            'remark' => 'Manual Internal Bank Transfer'
        ];
        CreditPayment::create($credit);
        DebitPayment::create($debit);
        return redirect()->route('admin.internal_bank_transfer')->with('message', 'Internal Bank Balance Transferred successfully.!');
    }

    public function create()
    {
        abort_if(Gate::denies('bank_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.banks.add_update');
    }

    public function store(StoreBankRequest $request)
    {
        $add = $request->all();
        $add['created_by'] = auth()->user()->id;
        $role = Bank::create($add);
        return redirect()->route('admin.payment_types.index')->with('message', 'Payment Type added successfully.!');
    }

    public function edit(Bank $payment_type)
    {
        die;
        abort_if(Gate::denies('bank_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $bank = $payment_type;
        return view('admin.banks.add_update', compact('bank'));
    }

    public function update(UpdateBankRequest $request, Bank $payment_type)
    {
        $edit = $request->all();
        $edit['updated_at'] = date('Y-m-d H:i:s');
        $edit['updated_by'] = auth()->user()->id;
        $payment_type->update($edit);
        return redirect()->route('admin.payment_types.index')->with('message', 'Payment Type updated successfully.!');
    }

    // public function show(Role $role)
    // {
    //     abort_if(Gate::denies('bank_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    //     $role->load('permissions');

    //     return view('admin.roles.show', compact('role'));
    // }

    public function destroy(Bank $payment_type)
    {
        abort_if(Gate::denies('bank_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $payment_type->delete();
        return back()->with('message', 'Payment Type deleted successfully.!');;
    }

    public function massDestroy(MassDestroyBankRequest $request, Bank $payment_type)
    {
        Bank::whereIn('id', request('ids'))->delete();
        return response('Payment Type deleted successfully.!', Response::HTTP_NO_CONTENT);
    }
}
