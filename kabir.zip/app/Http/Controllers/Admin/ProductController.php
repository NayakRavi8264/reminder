<?php

namespace App\Http\Controllers\Admin;

use App\Product;
use App\Category;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;

class ProductController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $product = Product::select('*');
            $product->with('category')->with('subcategory');
            $products = $product->get();
            return DataTables::of($products)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                           return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })
                ->addColumn('action', function($row){
                    $url = url('admin/products', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('product_edit')){
       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                return $actionBtn;
                })
                ->rawColumns(['action','status'])
                ->make(true);
        }
        return view('admin.products.index');
    }

    public function create() {
        abort_if(Gate::denies('product_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        $categories = Category::where('status', 1)->get();
        return view('admin.products.add_update', compact('categories'));
    }

    public function store(StoreProductRequest $request) {
        $data = $request->input();
        $data['created_by'] = auth()->user()->id;
        $product = Product::create($data);
        return redirect()->route('admin.products.index')->with('message', "Products added successfully.!");
    }

    public function edit(Product $product) {
        abort_if(Gate::denies('product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $categories = Category::where('status', 1)->get();
        return view('admin.products.add_update', compact('categories', 'product'));
    }
    public function update(UpdateProductRequest $request, Product $product) {
        $data = $request->input();
        $data['updated_by'] = auth()->user()->id;
        $data['subcategory_id'] = isset($data['subcategory_id'])?$data['subcategory_id']:"";
        $product->update($data);
        return redirect()->route('admin.products.index')->with('message', "Product updated successfully.!");
    }

}
