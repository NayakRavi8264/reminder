<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePurchasePaymentRequest;
use App\Http\Requests\UpdatePurchasePaymentRequest;
use App\Http\Requests\MassDestroyPurchaseRequest;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use Gate;
use App\Purchase;
use App\User;
use App\Project;
use DataTables;
use Session;

class PurchaseController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('purchase_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $payments = Purchase::select('*');
            // $payments = $payment->get();
            return DataTables::of($payments)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->editColumn('party', function ($row) {
                $party = "";
                if(isset($row->party->fname) && isset($row->party->lname)){
                    $party = $row->party->fname .' '.$row->party->lname;
                }
                return  $party;
                })->editColumn('project', function ($row) {
                    return isset($row->project->name)?$row->project->name:"";
                })->addColumn('action', function($row){
                    $url = url('admin/purchases', $row->id);
                    $actionBtn = "";

                if(\Gate::allows('purchase_edit')){
                $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                // if(\Gate::allows('purchase_delete')){
                // $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                // }
                return $actionBtn;
                })
                ->rawColumns(['action', 'status', 'party','project'])
                ->make(true);
        }
        return view('admin.purchases.index');
    }

    public function create() {
        abort_if(Gate::denies('purchase_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 4);
            // $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        $date = Session::get('date');
        Session::forget('date');
        return view('admin.purchases.add_update', compact('users', 'projects', 'date'));
    }

    public function store(StorePurchasePaymentRequest $request) {
        $data = $request->input();
        Purchase::create($data);
        Session::put('date', $request->post('date'));
        return redirect()->route('admin.purchases.create')->with('message', "Purchase added successfully.!");
    }

    public function edit(Purchase $purchase) {
        abort_if(Gate::denies('purchase_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 4);
        })->where('status', 1)->get();
        $projects = Project::where('status', 1)->get();

        return view('admin.purchases.add_update', compact('users', 'projects', 'purchase'));
    }
    public function update(UpdatePurchasePaymentRequest $request, Purchase $purchase) {
        $data = $request->input();
        $purchase->update($data);
        return redirect()->route('admin.purchases.index')->with('message', "Purchase updated successfully.!");
    }

    // public function destroy(CreditPayment $credit_payment)
    // {
    //     // abort_if(Gate::denies('credit_payment_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
    //     $credit_payment->delete();
    //     return response()->json([
    //         'status' => true,
    //         'message' => 'Record deleted successfully!',
    //     ]);
    // }

    public function massDestroy(MassDestroyPurchaseRequest $request)
    {
        Purchase::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
