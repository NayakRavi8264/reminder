<?php

namespace App\Http\Controllers\Admin;

use App\Client;
use App\Http\Requests\StoreClientRequest;
use App\Http\Requests\UpdateClientRequest;
use App\Http\Requests\MassDestroyClientRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;
use App\Category;

class ClientController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('client_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $clients = Client::select('*');
            // $clients = $client->get();
            return DataTables::of($clients)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })
                ->addColumn('action', function($row){
                    $url = url('admin/clients', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('client_edit')){
                $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                } 
                if(\Gate::allows('client_delete2')){
                $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                }
                
                return $actionBtn;
                })
                ->rawColumns(['action', 'status'])
                ->make(true);
        }
        return view('admin.clients.index');
    }

    public function create() {
        abort_if(Gate::denies('client_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
         $category = Category::pluck('name', 'id');
        return view('admin.clients.create', compact('category'));
    }
 
    public function store(StoreClientRequest $request) {
        $data = $request->input();
        $data['created_by'] = auth()->user()->id;
        Client::create($data);
        return redirect()->route('admin.clients.index')->with('message', "Clients added successfully.!");
    }

    public function edit(Client $client) {
        abort_if(Gate::denies('client_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
         $category = Category::pluck('name', 'id');
        return view('admin.clients.create', compact('client','category'));
    }
    public function update(UpdateClientRequest $request, Client $client) {
        $data = $request->input();
        $data['updated_by'] = auth()->user()->id;
        if($client->update($data)){
            return redirect()->route('admin.clients.index')->with('message', "Client updated successfully.!");
        } else{
            return back()->withInput()->with('error','Something went wrong,Please try after some time.!');
        }
    }

    public function destroy(Client $client)
    {
        abort_if(Gate::denies('client_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $client->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyClientRequest $request)
    {
        Client::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
