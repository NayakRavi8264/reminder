<?php

namespace App\Http\Controllers\Admin;

use App\Project;
use App\CreditPayment;
use App\DebitPayment;
use App\Client;
use App\User;
use App\Http\Requests\StoreProjectRequest;
use App\Http\Requests\UpdateProjectRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;

class ProjectController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('project_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $project = Project::select('*');
            $project->with('client');
            $projects = $project->get();
            return DataTables::of($projects)
                            ->addIndexColumn()
                            ->addColumn('select_row', function ($row) {
                                return '';
                            })->addColumn('tender_amount', function ($row) {
                                return number_format($row->tender_amount, 2);
                            })->addColumn('status', function ($row) {
                                return ($row->status == 1) ? "Active" : "Inactive";
                            })->addColumn('gst_balance', function ($row) {
                                return number_format(($row->purchases->sum('total_gst') + $row->credits->sum('cgst_tds') + $row->credits->sum('sgst_tds')) - $row->credits->sum('gst_amount'),2);
                            })->addColumn('balance', function ($row) {
                                return number_format($row->credits->sum('cheq_amount') - ($row->debits->sum('amount') + $row->payments->sum('amount') + $row->purchases->sum('total_bill_amount')),2);
                            })
                            ->addColumn('action', function($row) {
                                $url = url('admin/projects', $row->id);
                                $actionBtn = "";
                                if (\Gate::allows('project_edit')) {
                                    $actionBtn .= '<a class="btn btn-xs btn-info" href="' . $url . '/edit">Edit</a>';
                                    // $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger cancel-appointment">Delete?</a>';
                                }
//                if(\Gate::allows('party_ledger')){
                                $actionBtn .= ' <a class="btn btn-xs btn-primary" href="' . url('admin/payment_ledgers', $row->id) . '/project">Ledger By Admin</a>';
                                $actionBtn .= '  <a class="btn btn-xs btn-success" href="' . url('admin/payment_supervisors_ledgers', $row->id) . '/project">Ledger By Supervisor</a>';
                                $actionBtn .= '<a class="btn btn-xs btn-info" href="' . url('admin/project_report', $row->id) . '">View</a>';
//                }
                                return $actionBtn;
                            })
                            ->rawColumns(['action', 'status'])
                            ->make(true);
        }
        return view('admin.projects.index');
    }

    public function create() {
        abort_if(Gate::denies('project_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $clients = Client::pluck('name', 'id');
        $supervisors = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 3);
                })->get();
        return view('admin.projects.add_update', compact('clients', 'supervisors'));
    }

    public function store(StoreProjectRequest $request) {
        $data = $request->input();
        $data['created_by'] = auth()->user()->id;
        $project = Project::create($data);
        if (!empty($data['supervisors'])) {
            $project->supervisors()->sync($data['supervisors'], []);
        }

        if (strpos($data['trace_url'], "debit_payments/create") != false) {
            return redirect()->route('admin.debit_payments.create')->with('message', 'Party added successfully.!');
        }
        if (strpos($data['trace_url'], "credit_payments/create") != false) {
            return redirect()->route('admin.credit_payments.create')->with('message', 'Party added successfully.!');
        }

        return redirect()->route('admin.projects.index')->with('message', "Projects added successfully.!");
    }

    public function edit(Project $project) {
        abort_if(Gate::denies('project_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $clients = Client::pluck('name', 'id');
        $supervisors = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 3);
                })->get();
        return view('admin.projects.add_update', compact('project', 'clients', 'supervisors'));
    }

    public function update(UpdateProjectRequest $request, Project $project) {
        $data = $request->input();
        $data['updated_by'] = auth()->user()->id;
        $project->update($data);
        if (!empty($data['supervisors'])) {
            $project->supervisors()->sync($data['supervisors'], []);
        }
        return redirect()->route('admin.projects.index')->with('message', "Project updated successfully.!");
    }

    

    public function projectReport($pid){
        $project = Project::find($pid);
        return view('admin.projects.report', compact('project'));
    }
}
