<?php

namespace App\Http\Controllers\Admin;

use App\CreditPayment;
use App\User;
use App\Project;
use App\Client;
use App\Bank;
use App\Http\Requests\StoreCreditPaymentRequest;
use App\Http\Requests\UpdateCreditPaymentRequest;
use App\Http\Requests\MassDestroyCreditPaymentRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;
use Session;

class CreditPaymentController extends Controller {

    public function index(Request $request) {
        abort_if(Gate::denies('credit_payment_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $payment = CreditPayment::select('*');
            $payments = $payment->get();
            return DataTables::of($payments)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->editColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })->editColumn('party', function ($row) {
                    $party = "";
                    if(isset($row->party->fname) && isset($row->party->lname)){
                    return  $party = $row->party->fname .' '.$row->party->lname;
                    }
                })->editColumn('payment', function ($row) {
                    return isset($row->payment->name)?$row->payment->name:"";
                })->editColumn('client', function ($row) {
                    return isset($row->client->name)?$row->client->name:"";
                })->editColumn('project', function ($row) {
                    return isset($row->project->name)?$row->project->name:"";
                })->addColumn('action', function($row){
                    $url = url('admin/credit_payments', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('credit_payment_edit')){
       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                if(\Gate::allows('credit_payment_delete2')){
                $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                }
                return $actionBtn;
                })
                ->rawColumns(['action', 'status', 'party','payment','project'])
                ->make(true);
        }
        return view('admin.credit_payments.index');
    }

    public function create() {
        abort_if(Gate::denies('credit_payment_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 3);
            $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $payment_types = Bank::where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        $clients = Client::where('status', 1)->get();
        $date = Session::get('date');
        Session::forget('date');
        return view('admin.credit_payments.add_update', compact('users', 'payment_types', 'projects', 'clients', 'date'));
    }

    public function store(StoreCreditPaymentRequest $request) {
        $data = $request->input();
        $data['created_by'] = auth()->user()->id;
        CreditPayment::create($data);
        Session::put('date', $request->post('date'));
        return redirect()->route('admin.credit_payments.create')->with('message', "Credit Payment added successfully.!");
    }

    public function edit(CreditPayment $credit_payment) {
        abort_if(Gate::denies('credit_payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 3);
            $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $payment_types = Bank::where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        $clients = Client::where('status', 1)->get();
        return view('admin.credit_payments.add_update', compact('users', 'payment_types', 'projects', 'clients', 'credit_payment'));
    }
    public function update(UpdateCreditPaymentRequest $request, CreditPayment $credit_payment) {
        $data = $request->input();
        $data['updated_by'] = auth()->user()->id;
        $credit_payment->update($data);
        return redirect()->route('admin.credit_payments.index')->with('message', "Credit Payment updated successfully.!");
    }

    public function destroy(CreditPayment $credit_payment)
    {
        // abort_if(Gate::denies('credit_payment_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $credit_payment->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyCreditPaymentRequest $request)
    {
        CreditPayment::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
