<?php

namespace App\Http\Controllers\Admin;

use App\Project;
use App\CreditPayment;
use App\DebitPayment;
use App\Client;
use App\Task;
use App\Category;
use App\User;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use DataTables;

class TaskController extends Controller {

    public function index(Request $request) {
       
        // dd(request()->is('admin/task')); exit;
        abort_if(Gate::denies('task_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
       

        if ($request->ajax()) {

            $task = DB::table('tasks')
       
        ->select('tasks.id','tasks.task_name','clients.name as clients_name','tasks.status','tasks.start_date','tasks.end_date',DB::Raw("CONCAT(users.fname, ' ', users.lname) AS display_name"))
         ->leftJoin('clients','tasks.client_id','=','clients.id')
         ->leftJoin('users','users.id','=','tasks.user_id');
              if(session()->get('login_data')['user']['role'] != 1){
                $task->where('tasks.user_id',session()->get('login_data')['user']['id']);
              }
               if(isset($request->orderDateFrom) && $request->orderDateFrom != '' && isset($request->orderDateTo) && $request->orderDateTo != '' )
              {
                $formDate  = $request->orderDateFrom;
                $toDate  = $request->orderDateTo;
                $task->whereBetween('tasks.start_date',[$formDate,$toDate]);
              
              }
              if(isset($request->user_id) && $request->user_id != '' && $request->user_id != 'ALL'){
                $task->where('tasks.user_id',$request->user_id);
                 
              }

              if(isset($request->client_id) && $request->client_id != '' && $request->client_id != 'ALL'){
                $task->where('tasks.client_id',$request->client_id);
                
              }
              $task->whereNull('tasks.deleted_at');
        $tasks = $task->get();

            return DataTables::of($tasks)
                            ->addIndexColumn()
                            ->addColumn('select_row', function ($row) {
                                return '';
                            })->addColumn('status', function ($row) {
                                    return ($row->status == 1)?"Complated":(($row->status == 2) ? "Inprocess" : 'Pending');
                                
                            })->addColumn('action', function($row) {
                            
                                $url = url('admin/task', $row->id);
                                $actionBtn = "";
                                if (\Gate::allows('task_edit')) {
                                    $actionBtn .= '<a class="btn btn-xs btn-info mb-2" href="' . $url . '/edit">Edit</a>';
                                    // $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger cancel-appointment">Delete?</a>';
                                }

                                $actionBtn .= '<a class="btn btn-xs btn-info" href="' . url('admin/task', $row->id) . '">View</a>';

                                return $actionBtn;
                            })
                            ->rawColumns(['action', 'status'])
                            ->make(true);
        }
         $data['user'] = DB::table('users')->select('users.id',DB::Raw("CONCAT(fname,lname) as fullName"))->get();
        $data['client'] = DB::table('clients')->select('clients.id','clients.name as fullName')->get();
        return view('admin.task.index',$data);
    }

    public function create() {
        abort_if(Gate::denies('task_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $clients = Client::pluck('name', 'id');
       
        // dd($category);
        $supervisors = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 3);
                })->get();
        return view('admin.task.add_update', compact('clients', 'supervisors'));
    }

    public function store(StoreTaskRequest $request) {
        $data = $request->input();
    //   dd($data);
        $task_data = array(
          'task_name'=> $request->name,
          
          'user_id'=> $request->supervisors,
          'client_id'=> $request->client_id,
          'start_date'=>  date("Y-m-d", strtotime( $request->start_date)),
          'end_date'=>  date("Y-m-d", strtotime( $request->end_date)),
          'discription'=> $request->discription,
          'status'=> $request->status,


        );
        // dd($task_data);
        // $data['created_by'] = auth()->user()->id;
         $task = Task::create($task_data);

         return redirect()->route('admin.task.index')->with('message', "Task added successfully.!");
    }
    public function show(Task $task) {
        abort_if(Gate::denies('task_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

      $task['user_id'] = DB::table('users')->select(DB::Raw("CONCAT(users.fname, ' ', users.lname) AS display_name"))->where('id',$task['user_id'])->get()[0]->display_name;
    
      $task['client_id'] = DB::table('clients')->select('name')->where('id',$task['client_id'])->get()[0]->name;
      $task['status'] = ($task['status'] == 1) ? 'Complated' : (($task['status'] == 2) ? 'Inprocess' : 'Pending');
      $task['discription'] = DB::table('tasks')->select('discription')->where('id',$task['id'])->get()[0]->discription;
   

        return view('admin.task.show', compact('task'));
    }


    public function edit(task $task) {
        abort_if(Gate::denies('task_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $clients = Client::pluck('name', 'id');
     
        $supervisors = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 3);
                })->get();
                // dd($task);
        return view('admin.task.add_update', compact('task', 'clients', 'supervisors'));
    }

    public function update(UpdateTaskRequest $request, task $task) {
        $data = $request->input();
        $task_data = array(
            'task_name'=> $request->name,
            'user_id'=> $request->supervisors,
            'client_id'=> $request->client_id,
            'start_date'=>  date("Y-m-d", strtotime( $request->start_date)),
            'end_date'=>  date("Y-m-d", strtotime( $request->end_date)),
            'discription'=> $request->discription,
            'status'=> $request->status,
  
  
          );
        $task->update($task_data);
     
        return redirect()->route('admin.task.index')->with('message', "task updated successfully.!");
    }

    

    public function taskReport($pid){
        $task = task::find($pid);
        return view('admin.tasks.report', compact('task'));
    }

     public function destroy(Request $task) {
        abort_if(Gate::denies('task_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $id = $task->ids;
       

       Task::whereIn('id', $id)->delete();
        return back();
    }

     public function massDestroy(MassDestroyTaskRequest $request)
    {
        Task::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
