<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Gate;
use DB;
use Illuminate\Support\Facades\Schema;
use App\User;
use App\Payment;
use DataTables;
use Symfony\Component\HttpFoundation\Response;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExcelExport;

class CommonController extends Controller {

    public function paymentLedger(Request $request, $party_ledger, $type = NULL) {
        if ($request->ajax()) {
            if ($type == 'project') {
                $party_ledgers = $this->get_project_ledger($party_ledger);
            } elseif ($type == 'client') {
                $party_ledgers = $this->get_client_ledger($party_ledger);
            } elseif ($type == 'payment_types') {
                $party_ledgers = $this->bank_ledger($party_ledger);
            } else {
                $party_ledgers = $this->get_party_ledger($party_ledger);
            }
            return DataTables::of($party_ledgers)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('amt', function ($row) {
                    return number_format($row->amt, 2);
                })
                ->make(true);
        }
        return view('admin.ledger', compact('party_ledger', 'type'));
    }

    public function bank_ledger($party_ledger, $row_ids = []) {
        $party_ledgers = \DB::select('
            SELECT
            date,
            `cheq_amount` AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "credit" as type
            FROM
            `credit_payments`
            LEFT JOIN banks ON banks.id = credit_payments.payment_type 
            LEFT JOIN users ON users.id = credit_payments.user_id
            LEFT JOIN projects ON projects.id = credit_payments.project_id
            LEFT JOIN users as added_by ON added_by.id = credit_payments.created_by
            WHERE `banks`.id = ' . $party_ledger . '

            UNION ALL

            SELECT
            date,
            amount AS amt,
            remark as remark,
            banks.payment_method,
            banks.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "debit" as type
            FROM
            `debit_payments`
            LEFT JOIN banks ON banks.id = debit_payments.payment_type
            LEFT JOIN users ON users.id = debit_payments.user_id
            LEFT JOIN projects ON projects.id = debit_payments.project_id
            LEFT JOIN users as added_by ON added_by.id = debit_payments.created_by  WHERE `banks`.id = ' . $party_ledger . '
            ORDER BY DATE');
        return $party_ledgers;
    }

    public function get_party_ledger($party_ledger, $row_ids = []) {
        $party_ledgers = \DB::select('
            SELECT
            date,
            `cheq_amount` AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "credit" as type
            FROM
            `credit_payments`
            LEFT JOIN banks ON banks.id = credit_payments.payment_type
            LEFT JOIN projects ON projects.id = credit_payments.project_id 
            LEFT JOIN users ON users.id = credit_payments.user_id
            LEFT JOIN users as added_by ON added_by.id = credit_payments.created_by
            WHERE `users`.id = ' . $party_ledger . '

            UNION ALL

            SELECT
            date,
            amount AS amt,
            remark as remark,
            banks.payment_method,
            banks.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "debit" as type
            FROM
            `debit_payments`
            LEFT JOIN banks ON banks.id = debit_payments.payment_type
            LEFT JOIN users ON users.id = debit_payments.user_id
            LEFT JOIN projects ON projects.id = debit_payments.project_id
            LEFT JOIN users as added_by ON added_by.id = debit_payments.created_by  WHERE `users`.id = ' . $party_ledger . '

            UNION ALL

            SELECT
            date,
            total_bill_amount AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "purchase" as type
            FROM
            `purchases`
            LEFT JOIN users ON users.id = purchases.user_id
            LEFT JOIN banks ON banks.id = purchases.payment_type
            LEFT JOIN projects ON projects.id = purchases.project_id
            LEFT JOIN users as added_by ON added_by.id = purchases.created_by  WHERE `users`.id = ' . $party_ledger . '
            ORDER BY DATE');
        return $party_ledgers;
    }

    public function get_project_ledger($party_ledger, $row_ids = []) {
        $party_ledgers = \DB::select('
            SELECT
            date,
            `cheq_amount` AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "credit" as type
            FROM
            `credit_payments`
            LEFT JOIN banks ON banks.id = credit_payments.payment_type 
            LEFT JOIN projects ON projects.id = credit_payments.project_id
            LEFT JOIN users ON users.id = credit_payments.user_id
            LEFT JOIN users as added_by ON added_by.id = credit_payments.created_by
            WHERE `projects`.id = ' . $party_ledger . '

            UNION ALL

            SELECT
            date,
            amount AS amt,
            remark as remark,
            banks.payment_method,
            banks.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "debit" as type
            FROM
            `debit_payments`
            LEFT JOIN banks ON banks.id = debit_payments.payment_type
            LEFT JOIN projects ON projects.id = debit_payments.project_id
            LEFT JOIN users ON users.id = debit_payments.user_id
            LEFT JOIN users as added_by ON added_by.id = debit_payments.created_by  WHERE `projects`.id = ' . $party_ledger . ' 
            UNION ALL

            SELECT
            date,
            total_bill_amount AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "purchase" as type
            FROM
            `purchases`
            LEFT JOIN users ON users.id = purchases.user_id
            LEFT JOIN banks ON banks.id = purchases.payment_type
            LEFT JOIN projects ON projects.id = purchases.project_id
            LEFT JOIN users as added_by ON added_by.id = purchases.created_by  WHERE `projects`.id = ' . $party_ledger . '
            ORDER BY DATE');
        return $party_ledgers;
    }

    public function get_client_ledger($party_ledger, $row_ids = []) {
        $party_ledgers = \DB::select('
            SELECT
            date,
            `cheq_amount` AS amt,
            remark as remark,
            `banks`.payment_method,
            `banks`.name as bank_name,
            `projects`.name as project_name,
            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
            CONCAT(users.fname, " ", users.lname) as party_name,
            "credit" as type
            FROM
            `credit_payments`
            LEFT JOIN banks ON banks.id = credit_payments.payment_type 
            LEFT JOIN clients ON clients.id = credit_payments.client_id
            LEFT JOIN projects ON projects.id = credit_payments.project_id
            LEFT JOIN users ON users.id = credit_payments.user_id
            LEFT JOIN users as added_by ON added_by.id = credit_payments.created_by
            WHERE `clients`.id = ' . $party_ledger);
        return $party_ledgers;
    }

    public function exportLedger(Request $request) {
        $party_ledger = $request->input('party_ledger');
        $type = $request->input('type');
        if ($type == 'project') {
            $party_ledgers = $this->get_project_ledger($party_ledger);
        } elseif ($type == 'payment_types') {
            $party_ledgers = $this->bank_ledger($party_ledger);
        } else {
            $party_ledgers = $this->get_party_ledger($party_ledger);
        }
        $usersArr = [];
        foreach ($party_ledgers as $party_ledger) {
            $usersArr[] = array(
                'Date' => $party_ledger->date,
                'Amount' => $party_ledger->amt,
                'Type' => $party_ledger->type,
                'Payment Type' => $party_ledger->bank_name,
                'Payment Method' => $party_ledger->payment_method,
                'Added By User' => $party_ledger->created_by_name,
            );
        }
        $data['headings'] = [
            'Date',
            'Amount',
            'Type',
            'Payment Type',
            'Payment Method',
            'Added By User',
        ];
        $data['collection'] = $usersArr;
        return Excel::download(new ExcelExport($data), 'ledgers.xlsx');
    }

    // supervisor's ledger
    public function supervisorsLedgers(Request $request, $party_ledger, $type = NULL) {
        if ($request->ajax()) {
            $payments = $this->getPartyLedgerData($request, $party_ledger, $type);
            return DataTables::of($payments)
                            ->addIndexColumn()
                            ->addColumn('select_row', function ($row) {
                                return '';
                            })->addColumn('status', function ($row) {
                                return ($row->status == 1) ? "Active" : "Inactive";
                            })->addColumn('name', function ($row) {
                                $name = "";
                                if (!empty($row->suprvisor->fname) && !empty($row->suprvisor->lname)) {
                                    $name = $row->suprvisor->fname . " " . $row->suprvisor->lname;
                                }
                                return $name;
                            })->addColumn('project', function ($row) {
                                return isset($row->project->name) ? $row->project->name : "";
                            })->addColumn('added_by', function ($row) {
                                $user = "";
                                if (!empty($row->added_by->fname) && !empty($row->added_by->lname)) {
                                    $user = $row->added_by->fname . " " . $row->added_by->lname;
                                }
                                return $user;
                            })
                            ->addColumn('action', function($row) {
                                $url = url('admin/payments', $row->id);
                                $actionBtn = "";
                                if (\Gate::allows('payment_edit')) {
                                    $actionBtn .= '<a class="btn btn-xs btn-info" href="' . $url . '/edit">Edit</a>';
                                }
                                return $actionBtn;
                            })
                            ->rawColumns(['action', 'status', 'name', 'payment', 'added_by'])
                            ->make(true);
        }

        $users = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 4);
                    // $q->orWhere('roles.id', 4);
                })->where('status', 1)->get();
        $suprvisors = User::whereHas('roles', function($q) {
                    $q->where('roles.id', 3);
                })->where('status', 1)->get();
        return view('admin.supervisors_ledger', compact('party_ledger', 'users', 'suprvisors', 'type'));
    }

    public function getPartyLedgerData($request, $party_ledger, $type = NULL) {
        $payment = Payment::select('*');
        if (auth()->user()->roles()->first()->id == 1 OR auth()->user()->roles()->first()->title == "Admin") {
        } else {
           $payment->where('created_by', auth()->user()->id); 
        }
        if (!empty($request->input('created_by'))) {
            $payment->where('created_by', $request->input('created_by'));
        }
        if (!empty($request->input('from_date')) && !empty($request->input('to_date'))) {
            $payment->whereBetween('date', [$request->input('from_date'), $request->input('to_date')]);
        }
        if ($request->input('type') == "project" || $type == "project") {
            $payments = $payment->where('project_id', $party_ledger);
        } else{
            $payments = $payment->where('user_id', $party_ledger);
        }
        if ($request->input('is_export') == 'exportSupervisorsLedger') {
            $payments = $payment->get();
        }
        return $payments;
    }

    public function exportSupervisorsLedger(Request $request) {
        $payments = $this->getPartyLedgerData($request, $request->input('party_ledger'));
        // echo '<pre>';
        // print_r($payments[0]->suprvisor);die;
        $usersArr = [];
        foreach ($payments as $payment) {
            $usersArr[] = array(
                        'Project' => isset($payment->project->name) ? $payment->project->name : "",
                        'Party' => isset($payment->suprvisor->fname) ? $payment->suprvisor->fname." ".$payment->suprvisor->lname : "",
                        'Amount' => $payment->amount,
                        'Date' => $payment->date,
                        'Payment Type' => $payment->payment_type,
                        'Remark' => $payment->remark,
                        'Added By User' => $payment->added_by->fname . ' ' . $payment->added_by->lname,
            );
        }
        $data['headings'] = [
            'Project',
            'Party',
            'Amount',
            'Date',
            'Payment Type',
            'Remark',
            'Added By User',
        ];
        $data['collection'] = $usersArr;
        return Excel::download(new ExcelExport($data), 'supervisors_ledger.xlsx');
    }

}
