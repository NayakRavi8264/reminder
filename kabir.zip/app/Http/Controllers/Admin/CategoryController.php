<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Http\Requests\MassDestroyCategoryRequest;
use App\Category;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CategoryController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('category_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = Category::all();
        return view('admin.categories.index', compact('categories'));
    }

    public function create()
    {
        abort_if(Gate::denies('category_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $categories = Category::where('status', 1)->get();
        return view('admin.categories.add_update', compact('categories'));
    }

    public function store(StoreCategoryRequest $request)
    {
        $add = [
            'parent_id' => $request->input('parent_id'),
            'name' => $request->input('name'),
            'status' => $request->input('status'),
            'created_by' => auth()->user()->id
         ];
        Category::create($add);
        return redirect()->route('admin.categories.index')->with('message', 'Category added successfully.!');
    }

    public function edit(Category $category)
    {
        abort_if(Gate::denies('category_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $categories = Category::where('status', 1)->whereNotIn('id', [$category->id])->get();
        return view('admin.categories.add_update', compact('category', 'categories'));
    }

    public function update(UpdateCategoryRequest $request, Category $category)
    {
        $edit = [
            'parent_id' => $request->input('parent_id'),
            'name' => $request->input('name'),
            'status' => $request->input('status'),
            'updated_by' => auth()->user()->id,
        ];
        $category->update($edit);
        return redirect()->route('admin.categories.index')->with('message', 'Category updated successfully.!');
    }

    public function getCategories(Request $request, Category $category)
    {
        $category = Category::select('categories.*');
        $category->where('categories.status', 1);
        if($request->input('id')){
            $category->where('categories.parent_id', $request->input('id'));
        }
        $categories = $category->get();
        $data = ['result'=>true,'data'=>$categories];
        die(json_encode($data));
    }

    // public function show(Role $role)
    // {
    //     abort_if(Gate::denies('category_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    //     $role->load('permissions');

    //     return view('admin.roles.show', compact('role'));
    // }

    public function destroy(Category $category)
    {
        abort_if(Gate::denies('category_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $category->delete();
        return back()->with('message', 'Record deleted successfully.!');;
    }

    public function massDestroy(MassDestroyCategoryRequest $request)
    {
        Category::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
