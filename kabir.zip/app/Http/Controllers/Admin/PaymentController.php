<?php

namespace App\Http\Controllers\Admin;

use App\Payment;
use App\User;
use App\Project;
use App\PaymentToUser;
use App\CreditPayment;
use App\DebitPayment;
use App\Http\Requests\StorePaymentRequest;
use App\Http\Requests\UpdatePaymentRequest;
use App\Http\Requests\MassDestroyPaymentRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use DataTables;
use Session;

class PaymentController extends Controller {
    public function index(Request $request) {
        abort_if(Gate::denies('payment_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $payment = Payment::select('*');
            if(auth()->user()->roles()->first()->id == 3 OR auth()->user()->roles()->first()->title == "Supervisor"){
                $payment->where('created_by', auth()->user()->id);
            }
            if(!empty($request->input('user_id'))){
                $payment->where('user_id', $request->input('user_id'));
            }
            if(!empty($request->input('created_by'))){
                $payment->where('created_by', $request->input('created_by'));
            }
            if(!empty($request->input('from_date')) && !empty($request->input('to_date'))){
                $payment->whereBetween('date', [$request->input('from_date'), $request->input('to_date')]);
            }

            $payments = $payment->get();
            return DataTables::of($payments)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })->addColumn('name', function ($row) {
                    $name = "";
                    if(!empty($row->suprvisor->fname) && !empty($row->suprvisor->lname)){
                    $name = $row->suprvisor->fname." ". $row->suprvisor->lname;
                    }
                    return $name;
                })->addColumn('project', function ($row) {
                    return isset($row->project->name)?$row->project->name:"";
                })->addColumn('added_by', function ($row) {
                    $user = "";
                    if(!empty($row->added_by->fname) && !empty($row->added_by->lname)){
                    $user = $row->added_by->fname." ". $row->added_by->lname;
                    }
                    return $user;
                })
                ->addColumn('action', function($row){
                    $url = url('admin/payments', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('payment_edit')){
       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                if(\Gate::allows('payment_delete2')){
                $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                }
                return $actionBtn;
                })
                ->rawColumns(['action','status','name','payment','added_by'])
                ->make(true);
        }
        // $user = PaymentToUser::select('*');
        // if(auth()->user()->roles()->first()->id == 3 OR auth()->user()->roles()->first()->title == "Supervisor"){
        //         $user->where('created_by', auth()->user()->id);
        // }
        // $users = $user->get();

        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 4);
            // $q->orWhere('roles.id', 4);
        })->where('status', 1)->get();
        $suprvisors = User::whereHas('roles', function($q){
            $q->where('roles.id', 3);
        })->where('status', 1)->get();
        return view('admin.payments.index', compact('users', 'suprvisors'));
    }

    public function create() {
        abort_if(Gate::denies('payment_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        $balance = $this->userBalance();
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 4);
        })->where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        $date = Session::get('date');
        Session::forget('date');
        return view('admin.payments.add_update', compact('users', 'projects', 'balance', 'date'));
    }

    public function store(StorePaymentRequest $request) {
        $data = $request->input();
        Payment::create($data);
        Session::put('date', $request->post('date'));
        return redirect()->route('admin.payments.create')->with('message', "Payments added successfully.!");
    }

    public function edit(Payment $payment) {
        abort_if(Gate::denies('payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $balance = $this->userBalance();
        $users = User::whereHas('roles', function($q){
            $q->where('roles.id', 4);
        })->where('status', 1)->get();
        $projects = Project::where('status', 1)->get();
        return view('admin.payments.add_update', compact('payment', 'users', 'projects', 'balance'));
    }
    public function update(UpdatePaymentRequest $request, Payment $payment) {
        $data = $request->input();
        $payment->update($data);
        return redirect()->route('admin.payments.index')->with('message', "Payment updated successfully.!");
    }

    public function userBalance(){
        $creditBalance = CreditPayment::select('*')->where('user_id', auth()->user()->id)->get();
        
        $debitBalance = DebitPayment::select('*')->where('user_id', auth()->user()->id)->get();

        $payment_by_bank = Payment::where('payment_type', 'Bank')->where('created_by', auth()->user()->id)->sum('amount');

        $payment_by_cash = Payment::where('payment_type', 'Cash')->where('created_by', auth()->user()->id)->sum('amount');

        $balance = [];
        $totalBank = 0;
        $totalCash = 0;
        foreach($debitBalance as $debit){
            if($debit->payment->payment_method == "Bank"){
                $totalBank = $totalBank+$debit->amount;
            }else{
                $totalCash = $totalCash+$debit->amount;
            }
        }

        $totalCreditBank = 0;
        $totalCreditCash = 0;
        foreach($creditBalance as $credit){
            if($credit->payment->payment_method == "Bank"){
                $totalCreditBank = $totalCreditBank+$credit->cheq_amount;
            }else{
                $totalCreditCash = $totalCreditCash+$credit->cheq_amount;
            }
        }

        $bankBalance = ($totalBank-$totalCreditBank)-$payment_by_bank;
        $cashBalance = ($totalCash-$totalCreditCash)-$payment_by_cash;
        
        $balance['bankBalance'] = $bankBalance;
        $balance['cashBalance'] = $cashBalance;
        return $balance;
    }

    public function destroy(Payment $payment)
    {
        abort_if(Gate::denies('payment_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $payment->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyPaymentRequest $request)
    {
        Payment::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
