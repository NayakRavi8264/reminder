<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePartyRequest;
use App\Http\Requests\UpdatePartyRequest;
use App\Http\Requests\MassDestroyUserRequest;
use App\User;
use App\Payment;
use Gate;
use DataTables;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExcelExport;

class PartyController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('party_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $party = User::select('*');
            $party->whereHas('roles', function($q){
                $q->where('roles.id', 4);
            });
            $parties = $party->get();
            return DataTables::of($parties)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })->addColumn('fullname', function ($row) {
                    return $row->fname.' '.$row->lname;
                })->addColumn('user', function ($row) {
                    return $row->party_created_by->fname.' '.$row->party_created_by->lname;
                })->addColumn('balance', function ($row) {
                    return number_format((($row->debits->sum('amount') - $row->credits->sum('cheq_amount')) + $row->payments->sum('amount')) - $row->purchases->sum('total_bill_amount'),2);
                    // return number_format($row->credits->sum('cheq_amount') - $row->debits->sum('amount'),2);
                })
                ->addColumn('action', function($row){
                    $url = url('admin/parties', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('party_edit')){
                 $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                if(\Gate::allows('party_delete2')){
                $actionBtn .= ' <a data-val="'.$row->id.'" href="'.$url.'" class="btn btn-xs btn-danger delete-data">Delete</a>';
                }
                if(\Gate::allows('party_ledger')){
                $actionBtn .= ' <a class="btn btn-xs btn-primary" href="'.url('admin/payment_ledgers', $row->id).'">Ledger By Admin</a>';
                $actionBtn .= '  <a class="btn btn-xs btn-success" href="'.url('admin/payment_supervisors_ledgers', $row->id).'">Ledger By Supervisor</a>';
                }

                return $actionBtn;
                })
                ->rawColumns(['action', 'status', 'user', 'fullname'])
                ->make(true);
        }
        return view('admin.parties.index');
    }

    public function create()
    {
        abort_if(Gate::denies('party_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.parties.add_update');
    }

    public function store(StorePartyRequest $request)
    {
        $add = $request->all();
        $add['created_by'] = auth()->user()->id;
$add['password'] = "$2y$10$7Xn/8bPJ89ypj0cIxwoH9OOXnbK/.9xrLfFh2G4LUSRkw6j7Agn0K";
        $party = User::create($add);
        $party->roles()->sync([4]);

        if(strpos($add['trace_url'], "credit_payments/create") != false){
            return redirect()->route('admin.credit_payments.create')->with('message', 'Party added successfully.!');
        }
        if(strpos($add['trace_url'], "debit_payments/create") != false){
            return redirect()->route('admin.debit_payments.create')->with('message', 'Party added successfully.!');
        }

        return redirect()->route('admin.parties.index')->with('message', 'Party added successfully.!');
    }

    public function edit(User $party)
    {
        abort_if(Gate::denies('party_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.parties.add_update', compact('party'));
    }

    public function update(UpdatePartyRequest $request, User $party)
    {
        $edit = $request->all();
        $edit['updated_by'] = auth()->user()->id;
    $edit['password'] = "$2y$10$7Xn/8bPJ89ypj0cIxwoH9OOXnbK/.9xrLfFh2G4LUSRkw6j7Agn0K";
        $party->update($edit);
        $party->roles()->sync([4]);
        return redirect()->route('admin.parties.index')->with('message', 'Party updated successfully.!');
    }

//    public function partyLedger(Request $request, $party_ledger)
//    {    
//        if ($request->ajax()) {
//            $party_ledgers = $this->get_party_ledger($party_ledger);
//            return DataTables::of($party_ledgers)
//                ->addIndexColumn()
//                ->addColumn('select_row', function ($row) {
//                    return '';
//                })->addColumn('amt', function ($row) {
//                    return number_format($row->amt, 2);
//                })
//                ->make(true);
//        }
//        return view('admin.parties.ledger', compact('party_ledger'));
//    } 
//    public function get_party_ledger($party_ledger, $row_ids = []){
//        $party_ledgers = \DB::select('
//            SELECT
//            date,
//            `cheq_amount` AS amt,
//            `banks`.payment_method,
//            `banks`.name as bank_name,
//            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
//            "credit" as type
//            FROM
//            `credit_payments`
//            LEFT JOIN banks ON banks.id = credit_payments.payment_type 
//            LEFT JOIN users ON users.id = credit_payments.user_id
//            LEFT JOIN users as added_by ON added_by.id = credit_payments.created_by
//            WHERE `users`.id = '.$party_ledger.'
//
//            UNION ALL
//
//            SELECT
//            date,
//            amount AS amt,
//            banks.payment_method,
//            banks.name as bank_name,
//            CONCAT(added_by.fname, " ", added_by.lname) as created_by_name,
//            "debit" as type
//            FROM
//            `debit_payments`
//            LEFT JOIN banks ON banks.id = debit_payments.payment_type
//            LEFT JOIN users ON users.id = debit_payments.user_id
//            LEFT JOIN users as added_by ON added_by.id = debit_payments.created_by  WHERE `users`.id = '.$party_ledger.'
//            ORDER BY DATE');
//        return $party_ledgers;
//    }
//    public function exportLedger(Request $request) {
//        $party_ledgers = $this->get_party_ledger($request->input('party_ledger'));
//
//        $usersArr = [];
//        foreach ($party_ledgers as $party_ledger) {
//            $usersArr[] =
//                array(
//                'Date' => $party_ledger->date,
//                'Amount' => $party_ledger->amt,
//                'Type' => $party_ledger->type,
//                'Payment Type' => $party_ledger->bank_name,
//                'Payment Method' => $party_ledger->payment_method,
//                'Added By User' => $party_ledger->created_by_name,
//            );
//        }
//        $data['headings'] = [
//            'Date',
//            'Amount',
//            'Type',
//            'Payment Type',
//            'Payment Method',
//            'Added By User',
//        ];
//        $data['collection'] = $usersArr;
//        return Excel::download(new ExcelExport($data), 'party_ledger.xlsx');
//    }

//    public function partySupervisorsLedgers(Request $request, $party_ledger)
//    {    
//        if ($request->ajax()) {
//            $payments = $this->getPartyLedgerData($request, $party_ledger);
//            return DataTables::of($payments)
//                ->addIndexColumn()
//                ->addColumn('select_row', function ($row) {
//                    return '';
//                })->addColumn('status', function ($row) {
//                    return ($row->status == 1)?"Active":"Inactive";
//                })->addColumn('name', function ($row) {
//                    $name = "";
//                    if(!empty($row->suprvisor->fname) && !empty($row->suprvisor->lname)){
//                    $name = $row->suprvisor->fname." ". $row->suprvisor->lname;
//                    }
//                    return $name;
//                })->addColumn('project', function ($row) {
//                    return isset($row->project->name)?$row->project->name:"";
//                })->addColumn('added_by', function ($row) {
//                    $user = "";
//                    if(!empty($row->added_by->fname) && !empty($row->added_by->lname)){
//                    $user = $row->added_by->fname." ". $row->added_by->lname;
//                    }
//                    return $user;
//                })
//                ->addColumn('action', function($row){
//                    $url = url('admin/payments', $row->id);
//                    $actionBtn = "";
//                if(\Gate::allows('payment_edit')){
//       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
//                }
//                return $actionBtn;
//                })
//                ->rawColumns(['action','status','name','payment','added_by'])
//                ->make(true);
//        }
//
//        $users = User::whereHas('roles', function($q){
//            $q->where('roles.id', 4);
//            // $q->orWhere('roles.id', 4);
//        })->where('status', 1)->get();
//        $suprvisors = User::whereHas('roles', function($q){
//            $q->where('roles.id', 3);
//        })->where('status', 1)->get();
//        return view('admin.parties.party_supervisors_ledger', compact('party_ledger','users', 'suprvisors'));
//    }
//
//    public function getPartyLedgerData($request, $party_ledger){
//        $payment = Payment::select('*');
//        if(auth()->user()->roles()->first()->id == 3 OR auth()->user()->roles()->first()->title == "Supervisor"){
//            $payment->where('created_by', auth()->user()->id);
//        }
//        if(!empty($request->input('user_id'))){
//            $payment->where('user_id', $request->input('user_id'));
//        }
//        if(!empty($request->input('created_by'))){
//            $payment->where('created_by', $request->input('created_by'));
//        }
//        if(!empty($request->input('from_date')) && !empty($request->input('to_date'))){
//            $payment->whereBetween('date', [$request->input('from_date'), $request->input('to_date')]);
//        }
//        $payments = $payment->where('user_id', $party_ledger);
//        if($request->input('type') == 'exportSupervisorsLedger'){
//            $payments = $payment->get();
//        }
//        return $payments;
//    }
//
//    public function exportSupervisorsLedger(Request $request) {
//        $payments = $this->getPartyLedgerData($request, $request->input('party_ledger'));
//
//        $usersArr = [];
//        foreach ($payments as $payment) {
//            $usersArr[] =
//                array(
//                'Project' => isset($payment->project->name)?$payment->project->name:"",
//                'Amount' => number_format($payment->amount, 2),
//                'Date' => $payment->date,
//                'Remark' => $payment->remark,
//                'Added By User' =>  $payment->added_by->fname.' '.$payment->added_by->lname,
//            );
//        }
//        $data['headings'] = [
//            'Project',
//            'Amount',
//            'Date',
//            'Remark',
//            'Added By User',
//        ];
//        $data['collection'] = $usersArr;
//        return Excel::download(new ExcelExport($data), 'party_supervisors_ledger.xlsx');
//    }

    public function export(Request $request) {
        $user = User::select('users.*');
        $user->whereHas('roles', function($q){
            $q->where('id', 4);
        });
        if (!empty($request->input('ids'))) {
            $user->whereIn('id', explode(',', $request->input('ids')));
        }
        $users = $user->get();

        // echo "<pre>";print_r($users);die;
        $usersArr = [];
        foreach ($users as $user) {
            $usersArr[] =
                array(
                'First Name' => $user->fname,
                'Last Name' => $user->lname,
                'Mobile' => $user->mobile,
                'Email' => $user->email,
                'Pancard' => $user->pancard,
                'GSTIN' => $user->gstin,
                'IFSC Code' => $user->bank_ifsc_code,
                'Account Number' => $user->bank_account_number,
                'Balance' =>  number_format($user->credits->sum('cheq_amount') - $user->debits->sum('amount'),2),
                'Status' => $user->status?"Active":"Inactive",
            );
        }
        $data['headings'] = [
            'First Name',
            'Last Name',
            'Mobile',
            'Email',
            'Pancard',
            'GSTIN',
            'IFSC Code',
            'Account Number',
            'Balance',
            'Status',
        ];
        $data['collection'] = $usersArr;
        return Excel::download(new ExcelExport($data), 'parties.xlsx');
    }

    // public function show(Role $role)
    // {
    //     abort_if(Gate::denies('party_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    //     $role->load('permissions');

    //     return view('admin.roles.show', compact('role'));
    // }

    public function destroy(User $party)
    {
        abort_if(Gate::denies('party_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $party->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyUserRequest $request)
    {
        User::whereIn('id', request('ids'))->delete();
        return response()->json([
            'status' => true,
            'message' => 'Record deleted successfully!',
        ]);
    }
}
