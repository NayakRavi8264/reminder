<?php

namespace App\Http\Controllers\Admin;

use App\Project;
use App\CreditPayment;
use App\DebitPayment;
use App\Client;
use App\Task;
use App\Chat;
use App\Category;
use App\User;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use DataTables;

class TaskManagementController extends Controller
{
    public function index(Request $request) {
       
        
        abort_if(Gate::denies('task_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
       

        if ($request->ajax()) {

         $formDate  = $request->orderDateFrom;
         $toDate  = $request->orderDateTo;

      
          $where = ' WHERE 1=1 ';
           
            $task = DB::table('tasks')
              ->select('tasks.id','tasks.task_name','clients.name as clients_name','tasks.status','users.id as user_id','tasks.start_date','tasks.end_date',DB::Raw("CONCAT(users.fname, ' ', users.lname) AS display_name"))
              ->leftJoin('clients','tasks.client_id','=','clients.id')
              ->leftJoin('users','users.id','=','tasks.user_id');
              if(session()->get('login_data')['user']['role'] != 1){
                $task->where('tasks.user_id',session()->get('login_data')['user']['id']);
              }


              if(isset($request->orderDateFrom) && $request->orderDateFrom != '' && isset($request->orderDateTo) && $request->orderDateTo != '' )
              {
                $formDate  = $request->orderDateFrom;
                $toDate  = $request->orderDateTo;
                $task->whereBetween('tasks.start_date',[$formDate,$toDate]);
              
              }
              if(isset($request->user_id) && $request->user_id != '' && $request->user_id != 'ALL'){
                $task->where('tasks.user_id',$request->user_id);
                 
              }

              if(isset($request->client_id) && $request->client_id != '' && $request->client_id != 'ALL'){
                $task->where('tasks.client_id',$request->client_id);
                
              }
        $task->whereNull('tasks.deleted_at');
        $tasks = $task->get();

            return DataTables::of($tasks)
                            ->addIndexColumn()
                            ->addColumn('select_row', function ($row) {
                                return '';
                            })->addColumn('status', function ($row) {
                                  // $select = "";
                                  // for($i=1; $i <=3; $i++){
                                  //   $select = "<option></option>";
                                  // }
                                $one = "";
                                $two = "";
                                $three = "";
                                $color = "";
                                  switch ($row->status) {
                                      case '1':
                                          # code...
                                      $one = "selected";
                                      $color = "style='background-color:rgb(0, 200, 117)'";
                                          break;
                                      
                                       case '2':
                                          # code...
                                      $two = "selected";
                                      $color = "style='background-color:rgb(253, 171, 61)'";

                                          break;
                                      
                                       case '3':
                                          # code...
                                      $three = "selected";
                                      $color = "style='background-color:rgb(226, 68, 92)'";

                                          break;
                                      
                                      default:
                                          # code...
                                          break;
                                  }
                                  $data = json_encode($row);
                                 return "<select class='' onchange='getval(this);'' data-val ='".$data."' ".$color." style='width: 50%'>
                                       <option style='background-color:rgb(226, 68, 92)' value='3' ".$three." class='btn btn-info'><a>Pending</a></option>
                                       <option style='background-color:rgb(253, 171, 61)' value='2' ".$two.">Inprocess</option>
                                       <option style='background-color:rgb(0, 200, 117)' value='1' ".$one.">Complated</option>
                                      </select>";
                                // return $row->id;

                                   
                            })->addColumn('action', function($row) {
                            
                                $url = url('admin/task', $row->id);
                                $actionBtn = "";
                                $actionBtn .= '<a class="btn btn-xs btn-info" href="' . url('admin/task', $row->id) . '">View</a>';

                                return $actionBtn;
                            })->addColumn('chat',function($row){
                                $data = json_encode($row);
                                $chat = '';
                                $chat = "<i class='fa-fw fa fa-comment cdcdc' onclick='data(this)' data-toggle='modal'  data-target='.bd-example-modal-lg' data-val = '".$data."' style='cursor: pointer;'></i>";
                                return $chat;
                            })
                            ->rawColumns(['status','action','chat'])
                            ->make(true);
        }
          $data['user'] = DB::table('users')->select('users.id',DB::Raw("CONCAT(fname,lname) as fullName"))->get();
        $data['client'] = DB::table('clients')->select('clients.id','clients.name as fullName')->get();
        return view('admin.taskManagement.index',$data);
    }

    public function chat_call(Request $request){
     $task_id = $request->data['id'];
     $user_id = session()->get('login_data')['user']['id'];
     $chats = DB::table('chats')->leftJoin('users','chats.user_id','users.id')->where('chats.task_id',$task_id)->get();
     // echo "<pre>"; print_r($chats);
     $html = '<form method="POST" name="f1" id="f1">
       <div class="form-group">
        <textarea id="comment"  class="form-control comment" name ="comment"></textarea>
        </div>
        <input type="number" name="task_id" id="task_id" value="'.$task_id.'" hidden> 
        <input type="number" name="user_id" id="mineId" value="'.$user_id.'" hidden>
      
        <input type="button" class="btn btn-primary" name="submit" id="submit" value="SUBMIT" onclick="subm()">
      </form>
      <div>
       <center><div id="load_comments" class="comments">';
      if(!empty($chats)){
        foreach($chats as $k=>$val){
        $base_url = asset('img/dd.jpg');
            $html .= '<table >
              <col width="60">
              <col width="100">
              <col width="280">
              <col width="70">
              <tr>
              <td><img src="'.$base_url.'" width="42" height="42" style=" border-radius: 50%;"></td>
              <td align="center">'.$val->fname.' '.$val->lname.'</td>
                <td align="center">'.$val->chat_message.'</td>
              </tr><br></table>';
        }
      }
       
       $html .= '</div></center>  
      </div>';

  echo $html;

  
    }

    public function chat_submit(Request $request){
        $task_id = $request->task_id;
        $user_id = session()->get('login_data')['user']['id'];
        $comment = $request->comment;
        $submit = array(
        'task_id' => $task_id,
        'user_id' => $user_id,
        'chat_message' =>$comment
        );

      $task = Chat::create($submit);
      echo $task_id;

    }

    public function load_content(Request $id){
         $task_id = $id->task_id; 
         $chats = DB::table('chats')->leftJoin('users','chats.user_id','users.id')->where('chats.task_id',$task_id)->get();
         $html = '';
         if(!empty($chats)){
        foreach($chats as $k=>$val){
        $base_url = asset('img/dd.jpg');
            $html .= '<table >
              <col width="60">
              <col width="100">
              <col width="280">
              <col width="70">
              <tr>
              <td><img src="'.$base_url.'" width="42" height="42" style=" border-radius: 50%;"></td>
              <td align="center">'.$val->fname.' '.$val->lname.'</td>
                <td align="center">'.$val->chat_message.'</td>
              </tr><br></table>';
        }
      }
      echo $html;
    }
   
   public function status_update(Request $request){
      $task_id = $request->data['id'];
      $new_status = $request->new_status;

     $update = array(
       'status' => $new_status
     );
     $status = Task::where('id',$task_id)->update($update);
     echo $new_status;
   }

}
