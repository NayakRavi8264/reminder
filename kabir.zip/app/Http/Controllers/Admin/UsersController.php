<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Requests\UpdateProfileRequest;
use App\Http\Requests\UpdatePasswordRequest;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Role;
use App\User;
use Illuminate\Support\Facades\Hash;

class UsersController extends Controller {

    public function index() {
        abort_if(Gate::denies('user_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::whereHas('roles', function($q) {
                    $q->where('id', '!=', 4);
                })->get();

        return view('admin.users.index', compact('users'));
    }

    public function create() {
        abort_if(Gate::denies('user_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roles = Role::pluck('title', 'id');

        return view('admin.users.create', compact('roles'));
    }

    public function store(StoreUserRequest $request) {
        $data = $request->all();
        $user = User::create($data);
        $user->roles()->sync($request->input('roles', []));

        return redirect()->route('admin.users.index');
    }

    public function edit(User $user) {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $roles = Role::pluck('title', 'id');
        $user->load('roles');

        return view('admin.users.create', compact('roles', 'user'));
    }

    public function update(UpdateUserRequest $request, User $user) {
        $data = $request->all();
        $user->update($data);
        $user->roles()->sync($request->input('roles', []));

        return redirect()->route('admin.users.index');
    }

    public function show(User $user) {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->load('roles');

        return view('admin.users.show', compact('user'));
    }

    public function destroy(User $user) {
        abort_if(Gate::denies('user_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->delete();

        return back();
    }

    public function massDestroy(MassDestroyUserRequest $request) {
        User::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function changePassword() {
        $user = User::where('id', auth()->user()->id)->first();
        return view('admin.users.change_password', compact('user'));
    }

    public function updateProfile() {
        $user = User::where('id', auth()->user()->id)->first();
        return view('admin.users.update_profile', compact('user'));
    }

    public function saveProfile(UpdateProfileRequest $request) {
        User::find(auth()->user()->id)->update($request->all());
        return redirect()->route('admin.users.update_profile')->with('message', 'Profile updated successfully.!');
    }

    public function savePassword(UpdatePasswordRequest $request) {
        User::find(auth()->user()->id)->update(['password' => Hash::make($request->input('password'))]);
        return redirect()->route('admin.users.change_password')->with('message', 'Password updated successfully.!');
    }

}
