<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
// use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StorePaymentToUserRequest;
use App\Http\Requests\UpdatePaymentToUserRequest;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\PaymentToUser;
use Gate;
use DataTables;

class PaymentToUserController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('access_payments_to_users'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $payment = PaymentToUser::select('*');
             if(auth()->user()->roles()->first()->id == 3 OR auth()->user()->roles()->first()->title == "Supervisor"){
                $payment->where('created_by', auth()->user()->id);
            }
            $payments = $payment->get();
            return DataTables::of($payments)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })->addColumn('status', function ($row) {
                    return ($row->status == 1)?"Active":"Inactive";
                })->addColumn('action', function($row){
                    $url = url('admin/payments_to_users', $row->id);
                    $actionBtn = "";
                if(\Gate::allows('edit_payments_to_users')){
       $actionBtn .= '<a class="btn btn-xs btn-info" href="'.$url.'/edit">Edit</a>';
                }
                return $actionBtn;
                })
                ->rawColumns(['action', 'status'])
                ->make(true);
        }
        return view('admin.payments_to_users.index');
    }

    public function create()
    {
        abort_if(Gate::denies('create_payments_to_users'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.payments_to_users.create');
    }

    public function store(StorePaymentToUserRequest $request)
    {
        $data = $request->all();
        $data['created_by'] = auth()->user()->id;
        $user = PaymentToUser::create($data);
        return redirect()->route('admin.payments_to_users.index')->with('message', 'Payment User added successfully.!');
    }

    public function edit(PaymentToUser $payments_to_user)
    {
        $payment_to_user = $payments_to_user;
        abort_if(Gate::denies('edit_payments_to_users'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.payments_to_users.create', compact('payment_to_user'));
    }

    public function update(UpdatePaymentToUserRequest $request, PaymentToUser $payments_to_user)
    {
        $data = $request->all();
        $data['updated_by'] = auth()->user()->id;
        $data['updated_at'] = date('Y-m-d H:i:s');
        $payments_to_user->update($data);
        return redirect()->route('admin.payments_to_users.index')->with('message', 'Payment User updated successfully.!');
    }

    public function show(User $user)
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->load('roles');

        return view('admin.users.show', compact('user'));
    }

    public function destroy(User $user)
    {
        abort_if(Gate::denies('user_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->delete();

        return back();
    }

    public function massDestroy(MassDestroyUserRequest $request)
    {
        User::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function changePassword(){
        $user = User::where('id', auth()->user()->id)->first();
        return view('admin.users.change_password', compact('user'));
    }

    public function updateProfile(){
        $user = User::where('id', auth()->user()->id)->first();
        return view('admin.users.update_profile', compact('user'));
    }

    public function saveProfile(UpdateProfileRequest $request) {
        User::find(auth()->user()->id)->update($request->all());
        return redirect()->route('admin.users.update_profile')->with('message', 'Profile updated successfully.!');
    }

    public function savePassword(UpdatePasswordRequest $request) {
        User::find(auth()->user()->id)->update(['password' => Hash::make($request->input('password'))]);
        return redirect()->route('admin.users.change_password')->with('message', 'Password updated successfully.!');
    }

}
