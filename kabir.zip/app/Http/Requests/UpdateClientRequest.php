<?php

namespace App\Http\Requests;

use App\Client;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateClientRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('client_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'max:255',
            ],
            'email' => [
                // 'required',
                'nullable',
                'max:100',
                'unique:clients,email,'.request()->route('client')->id.',id,deleted_at,NULL',

            ],
            'gstin' => [
                // 'required',
                'max:20',
            ],
            'contact_person_name' => [
                // 'required',
                'max:255',
            ],
            'contact_person_mobile' => [
                // 'required',
                'nullable',
              
                'numeric'
            ],
        ];
    }

    public function messages(){
        return [
            'gstin.required' => "The GSTIN field is required."
        ];
    }
}
