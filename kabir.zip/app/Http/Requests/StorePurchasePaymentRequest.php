<?php

namespace App\Http\Requests;

use App\Purchase;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StorePurchasePaymentRequest extends FormRequest
{
    public function authorize()
    {
        // abort_if(Gate::denies('purchase_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'bill_no' => [
                'required',
            ],
            'basic_bill_amount' => [
                'required',
                'numeric'
            ],
            'total_bill_amount' => [
                'required',
                'numeric'
            ],
            'sgst' => [
                'required',
                'numeric'
            ],
            'cgst' => [
                'required',
                'numeric'
            ],
            'igst' => [
                'required',
                'numeric'
            ],
            'total_gst' => [
                'required',
                'numeric'
            ],
            'date' => [
                'required',
            ],
            'user_id' => [
                'required',
                'numeric'
            ],
            'project_id' => [
                'required',
                'numeric'
            ],
        ];
    }
     public function messages(){
        return [
            'user_id.required' => "The Party field is required.",
            'project_id.required' => "The Project field is required."
        ];
    }
}
