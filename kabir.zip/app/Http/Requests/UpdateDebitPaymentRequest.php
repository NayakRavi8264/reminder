<?php

namespace App\Http\Requests;

use App\DebitPayment;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateDebitPaymentRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('debit_payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'amount' => [
                'required',
                'numeric'
            ],
            // 'gst_amount' => [
            //     'required',
            //     'numeric'
            // ],
            // 'tds_amount' => [
            //     'required',
            //     'numeric'
            // ],
            // 'hold_amount' => [
            //     'required',
            //     'numeric'
            // ],
            'payment_type' => [
                'required',
            ],
            'date' => [
                'required',
            ],
            'user_id' => [
                'required','numeric'
            ],
            'project_id' => [
                'required','numeric'
            ],
        ];
    }
     public function messages(){
        return [
            'user_id.required' => "The Party field is required.",
            'project_id.required' => "The Project field is required."
        ];
    }
}
