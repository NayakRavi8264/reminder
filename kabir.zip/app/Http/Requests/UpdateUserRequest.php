<?php

namespace App\Http\Requests;

use App\User;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateUserRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'fname'     => [
                'required',
                'max:255',
            ],
            'lname'     => [
                'required',
                'max:255',
            ],
            'mobile'     => [
                'required',
                'numeric',
            ],
            'dob'     => [
                'required',
                'date',
            ],
            'password'  => [
                'nullable',
                'min:8',
            ],
            'confirm_password'  => [
                'nullable',
                'min:8',
                'same:password',
            ],
            'email'   => [
                'required'
                ,'email'
                ,'unique:users,email,'.request()->route('user')->id,
            ],
            'roles.*' => [
                'integer',
            ],
            'roles'   => [
                'required',
                'array',
            ],
        ];
    }
    
    public function messages() {
        return [
            'email.unique'  => "The Email must be unique."
        ];
    }
}
