<?php

namespace App\Http\Requests;

use App\User;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateProfileRequest extends FormRequest {

    // public function authorize() {
    //     abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    //     return true;
    // }

    public function rules() {
        return [
               'fname'     => [
                'required',
                'max:255',
            ],
            'lname'     => [
                'required',
                'max:255',
            ],
            'mobile'     => [
                'required',
                'numeric',
            ],
            'email' => [
                'required', 'unique:users,email,'.auth()->user()->id,
            ],
        ];
    }
}
