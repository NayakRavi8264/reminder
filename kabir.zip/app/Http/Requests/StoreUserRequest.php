<?php

namespace App\Http\Requests;

use App\User;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreUserRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('user_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'fname'     => [
                'required',
                'max:255',
            ],
            'lname'     => [
                'required',
                'max:255',
            ],
            'mobile'     => [
                'required',
                'numeric',
            ],
            'dob'     => [
                'required',
                'date',
            ],
            'email'   => [
                'required'
                ,'email'
                ,'unique:users',
            ],
            'password'  => [
                'required',
                'string',
                'min:8',
            ],
            'confirm_password'  => [
                'required',
                'string',
                'min:8',
                'same:password',
            ],
            'roles.*'  => [
                'integer',
            ],
            'roles'    => [
                'required',
                'array',
            ],
        ];
    }
    
    public function messages() {
        $name = "Enrollment Id";
        if(request()->post('user_type') == "4"){
            $name = "Company Name";
        }
        return [
            'enrollment_id.required'  => "The ".$name." field is required."
        ];
    }
}
