<?php

namespace App\Http\Requests;

use App\Bank;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreBankRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('bank_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'max:255',
                'unique:banks',
            ],
        ];
    }

    public function messages(){
        return [
            'name.required' => "The Name field is required.",
            'name.unique' => "This Payment Type is already exists in the system.",
        ];
    }
}
