<?php

namespace App\Http\Requests;

use App\CreditPayment;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateCreditPaymentRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('credit_payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'bill_amount' => [
                'required',
                'numeric'
            ],
            'net_bill_amount' => [
                'required',
                'numeric'
            ],
            'gst_amount' => [
                'required',
                'numeric'
            ],
            'payment_type' => [
                'required',
            ],
            'date' => [
                'required',
            ],
            'user_id' => [
                'nullable',
                // 'required',
                'numeric'
            ],
             'client_id' => [
                'required','numeric'
            ],
            'project_id' => [
                'required','numeric'
            ],
        ];
    }
     public function messages(){
        return [
            'user_id.required' => "The Party field is required.",
            'client_id.required' => "The Client field is required.",
            'project_id.required' => "The Project field is required."
        ];
    }
}
