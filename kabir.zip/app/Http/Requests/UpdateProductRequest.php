<?php

namespace App\Http\Requests;
use App\Product;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateProductRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'max:255',
                'unique:products,name,'.request()->route('product')->id,
            ],
            'price' => [
                'required',
                'numeric',
            ],
            'description' => [
                'nullable',
                'max:500',
            ],
            'category_id'   => [
                'required',
                'integer',
            ],
            'subcategory_id'   => [
                'integer',
            ],
        ];
    }
}
