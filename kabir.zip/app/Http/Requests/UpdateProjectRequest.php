<?php

namespace App\Http\Requests;
use App\Project;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class UpdateProjectRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('project_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'max:255',
            ],
            'contact_person_name' => [
                // 'required',
                'max:255',
            ],
            'contact_person_mobile' => [
                // 'required',
                'nullable',
                'max:10',
                'min:10',
            ],
            'client_id'   => [
                'nullable',
                'integer',
            ],
        ];
    }
}
