<?php

namespace App\Http\Requests;

use App\User;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StorePartyRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('party_create'), Response::HTTP_FORBIDDEN,'403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'fname' => [
                'required',
                'max:255',
            ],
             'lname' => [
                'required',
                'max:255',
            ],
            'pancard' => [
                // 'required',
                'nullable',
                'max:100',
                'unique:users,pancard,NULL,id,deleted_at,NULL',
            ],
             'email'   => [
                // 'required',
                'nullable',
                'email',
                'unique:users,email,NULL,id,deleted_at,NULL',
            ],
            'gstin' => [
                // 'required',
                'nullable',
                'max:100',
            ],
            'mobile' => [
                // 'required',
                'nullable',
                'numeric'
            ],
            'bank_account_number' => [
                'nullable',
            ],
        ];
    }

    public function messages(){
        return [
            'gstin.required' => "The GSTIN field is required."
        ];
    }
}
