<?php

namespace App\Http\Requests;

use App\Payment;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StorePaymentRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('payment_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
            'amount' => [
                'required',
                'numeric'
            ],
            'project_id' => [
                'required',
            ],
            'date' => [
                'required',
            ],
            'user_id' => [
                'required','numeric'
            ],
            'payment_type' => [
                'required'
            ],
        ];
    }
     public function messages(){
        return [
            'user_id.required' => "The Payment User field is required."
        ];
    }
}
