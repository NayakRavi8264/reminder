<?php

namespace App\Http\Requests;

use App\PaymentToUser;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StorePaymentToUserRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('create_payments_to_users'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'name'     => [
                'required',
                'max:255',
            ],
            'mobile'     => [
                'required',
                'numeric',
            ],
            'remark'     => [
                'required',
                'max:500',
            ],
        ];
    }
}
