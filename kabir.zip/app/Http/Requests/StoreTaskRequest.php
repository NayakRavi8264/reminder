<?php

namespace App\Http\Requests;
use App\Task;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreTaskRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('task_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return true;
    }

    public function rules()
    {
        return [
           
            'supervisors'   => [
                'required',
                'integer',
            ],
            'name' => [
                'required',
                'max:255',
                'unique:products',
            ],
            'start_date'     => [
                'required',
                'date',
            ],
             'end_date'     => [
                'required',
                'date',
            ],
            'client_id' => [
                'required',
                'integer',
            ],
            'discription' => [
                'required',
                'max:500',
            ]
           
          
        ];
    }
}
