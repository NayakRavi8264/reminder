<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use \Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class Payment extends Model
{
    use HasFactory, UserActionsBy;
    
    public $table = 'payments';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'amount',
        'payment_type',
        'project_id',
        'user_id',
        'date',
        'remark',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function suprvisor(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function project(){
        return $this->belongsTo(Project::class);
    }

    public function added_by(){
        return $this->hasOne(User::class, 'id', 'created_by');
    }
}
