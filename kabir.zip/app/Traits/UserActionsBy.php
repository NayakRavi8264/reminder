<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Schema;

trait UserActionsBy
{
    protected static function bootUserActionsBy()
    {
        static::creating(function ($model) {
            if (auth()->check()) {
                if (Schema::hasColumn($model->getTable(), 'created_by')){
                    $model->created_by =auth()->id();
                }
                if (Schema::hasColumn($model->getTable(), 'updated_at')){
                    $model->updated_at =NULL;
                }
            }
        });

        static::updating(function ($model) {
            if(auth()->check()) {
                if(Schema::hasColumn($model->getTable(), 'updated_by')){
                    $model->updated_by =auth()->id();
                }
            }
            
        });

        static::deleting(function ($model) {
            if (auth()->check()) {
                if (Schema::hasColumn($model->getTable(), 'deleted_by')){
                    $model->deleted_by =auth()->id();
                }
            }
            if (Schema::hasColumn($model->getTable(), 'updated_at')){
                $model->timestamps = false;
            }
            $model->save();
        });
    }
}
