<?php
namespace App\Traits;

use Illuminate\Support\Facades\Storage;
use Image;
use Config;
trait UploadImageTrait
{
    public function UploadImage($ImgArr)
    {
        /*if(isset($ImgArr['old_img']) && !empty($ImgArr['old_img'])){
           Storage::disk('s3')->delete($ImgArr['old_img']);
        }*/
        $new_image_name=$ImgArr['img_name'];
        $filePath = $ImgArr['folder_name'].'/'.$new_image_name;
        if(preg_match('/^data:image\/(\w+);base64,/', $ImgArr['files'])) 
        {
            $data = substr($ImgArr['files'], strpos($ImgArr['files'], ',') + 1);
            $data = base64_decode($data);
            Storage::disk('s3')->put($filePath,$data,'public');
        }else{
            Storage::disk('s3')->put($filePath,file_get_contents($ImgArr['files']),'public');
        }
    }
}