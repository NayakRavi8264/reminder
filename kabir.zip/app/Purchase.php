<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use \Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class Purchase extends Model
{
    use HasFactory, UserActionsBy;
    
    public $table = 'purchases';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'id',
        'date', 
        'bill_no', 
        'basic_bill_amount',
        'total_gst',
        'total_bill_amount', 
        'cgst',
        'sgst',
        'igst',
        'user_id', 
        'project_id',
        'remark',
        'created_at', 
        'updated_at', 
        'deleted_at', 
        'created_by',
        'updated_by',
        'deleted_by'
    ];

    public function user(){
        return $this->hasOne(User::class, 'id', 'created_by');
    }

    public function party(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function payment(){
        return $this->hasOne(Bank::class, 'id', 'payment_type');
    }

    public function project(){
        return $this->hasOne(Project::class, 'id', 'project_id');
    }

    public function client(){
        return $this->hasOne(Client::class, 'id', 'client_id');
    }
}
