<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class Product extends Model
{
use HasFactory, UserActionsBy;

protected $table = "products";

protected $dates = [
    'created_at',
    'updated_at',
    'deleted_at'
];

protected $fillable = [
"id", "category_id", "subcategory_id", "name", "price", "description", "status", "created_at", "updated_at", "deleted_at", "created_by", "updated_by", "deleted_by"
]; 

public function category(){
    return $this->hasOne(Category::class, 'id', 'category_id');
}

public function subcategory(){
return $this->hasOne(Category::class, 'id', 'subcategory_id');
}
}
