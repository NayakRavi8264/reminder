<?php
use Carbon\Carbon as Carbon;

if(!function_exists('mdyToYmd')) {
    function mdyToYmd($dt)
    {
        $dt = explode('-',$dt);
        return $dt[2] . '-' . $dt[0] . '-' . $dt[1];
    }
}

if(!function_exists('ymdToMdy')) {
    function ymdToMdy($dt)
    {
        if(empty($dt)){
            return ;
        }
        
        $dt = explode('-',$dt);
        return $dt[1] . '-' . $dt[2] . '-' . $dt[0];
    }
}
?>