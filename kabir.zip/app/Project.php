<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use \Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class Project extends Model
{
    use HasFactory, UserActionsBy;
    
    public $table = 'projects';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'address',
        'client_id',
        'contact_person_name',
        'contact_person_mobile', 
        'work_order_date', 
        'estimate_amount', 
        'above_below_parasite', 
        'tender_amount', 
        'work_order_number', 
        'sd_number', 
        'work_conflict_date', 
        'actual_work_conflict_date', 
        'sd_release_date', 
        'form3a_date', 
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function client(){
        return $this->belongsTo(Client::class);
    }
    public function supervisors(){
        return $this->belongsToMany(User::class);
    }

    public function credits() {
        return $this->hasMany(CreditPayment::class, 'project_id', 'id');
    }

    public function debits() {
        return $this->hasMany(DebitPayment::class, 'project_id', 'id');
    }

    public function purchases() {
        return $this->hasMany(Purchase::class, 'project_id', 'id');
    }

    public function payments() {
        return $this->hasMany(Payment::class, 'project_id', 'id');
    }
}
