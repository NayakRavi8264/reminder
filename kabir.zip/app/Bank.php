<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\UserActionsBy;

class Bank extends Model
{
    use UserActionsBy;
    // use SoftDeletes;

    public $table = 'banks';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'status',
        'payment_method',
        'created_by',
        'updated_by',
        'deleted_by',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function users()
    {
        return $this->belongsToMany(User::class);
    }
    
    public function credits()
    {
        return $this->hasMany(CreditPayment::class, 'payment_type', 'id');
    }

    public function debits()
    {
        return $this->hasMany(DebitPayment::class, 'payment_type', 'id');
    }
}
