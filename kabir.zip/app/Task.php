<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Task extends Model
{
    
    use SoftDeletes,HasFactory;
    public $table = 'tasks';

    protected $dates = [
        'created_at',
        'updated_at',
    
    ];

    protected $fillable = [
        'task_name',
        'user_id',
        'start_date',
        'end_date',
        'discription',
        'client_id',
        'status',
        'created_at',
        'updated_at',
        'deleted_at',
    ];
    public function client(){
        return $this->belongsTo(Client::class);
    }
    public function category(){
        return $this->hasOne(Category::class, 'id', 'category_id');
    }
    
}
