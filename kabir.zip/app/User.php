<?php

namespace App;

use Carbon\Carbon;
use Hash;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use App\Traits\UserActionsBy;

class User extends Authenticatable {

    use SoftDeletes,
        Notifiable,
        HasApiTokens,
        UserActionsBy;

    public $table = 'users';
    protected $hidden = [
        'password',
        'remember_token',
    ];
    protected $dates = [
        'updated_at',
        'created_at',
        'deleted_at',
        'email_verified_at',
    ];
    protected $fillable = [
        'bank',
        'fname',
        'lname',
        'dob',
        'pancard',
        'gstin',
        'mobile',
        'bank_ifsc_code',
        'bank_account_number',
        'address',
        'created_by',
        'updated_by',
        'deleted_by',
        'address1',
        'email',
        'password',
        'created_at',
        'updated_at',
        'deleted_at',
        'remember_token',
        'email_verified_at',
        'status',
    ];

    public function getEmailVerifiedAtAttribute($value) {
        return $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value)->format(config('panel.date_format') . ' ' . config('panel.time_format')) : null;
    }

    public function setEmailVerifiedAtAttribute($value) {
        $this->attributes['email_verified_at'] = $value ? Carbon::createFromFormat(config('panel.date_format') . ' ' . config('panel.time_format'), $value)->format('Y-m-d H:i:s') : null;
    }

    public function setPasswordAttribute($input) {
        if ($input) {
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
        }
    }

    public function sendPasswordResetNotification($token) {
        $this->notify(new ResetPassword($token));
    }

    public function roles() {
        return $this->belongsToMany(Role::class);
    }

    public function projects() {
        return $this->belongsToMany(Project::class);
    }

    public function getFullNameAttribute() {
        return $this->fname . ' ' . $this->lname;
    }

    public function getIsAdminAttribute() {
        return $this->roles()->where('id', 1)->exists();
    }

    public function getIsUserAttribute() {
        return $this->roles()->where('id', 2)->exists();
    }

    public function party_created_by() {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function credits() {
        return $this->hasMany(CreditPayment::class, 'user_id', 'id');
    }

    public function debits() {
        return $this->hasMany(DebitPayment::class, 'user_id', 'id');
    }

    public function purchases() {
        return $this->hasMany(Purchase::class, 'user_id', 'id');
    }

    public function payments() {
        return $this->hasMany(Payment::class, 'user_id', 'id');
    }
}
